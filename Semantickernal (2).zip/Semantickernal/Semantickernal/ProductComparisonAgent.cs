﻿using Microsoft.SemanticKernel;
using System.Threading.Tasks;
namespace Semantickernal
{
    public class ProductPlugin
    {
        [KernelFunction("fetch_product_data")]
        public async Task<string> FetchProductDataAsync(string productName)
        {
            // Simulate fetching product data
            await Task.Delay(500); // Simulate delay
            return $"Data for {productName}: Price $499, Rating 4.5, Features X, Y, Z";
        }
    }
}
