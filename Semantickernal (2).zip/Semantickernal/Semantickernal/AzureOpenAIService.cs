using System.Net.Http;
using System.Text.Json;
using System.Text;
using System.Threading.Tasks;

public class AzureOpenAIService
{
    private readonly string endpoint = "https://soumenopenai.openai.azure.com";
    private readonly string apiKey = "your-api-key";
    private readonly string modelId = "gpt-4";

    private readonly HttpClient _client;

    public AzureOpenAIService(HttpClient client)
    {
        _client = client;
        _client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");
    }

    public async Task<string> GetAIResponseAsync(string prompt)
    {
        var requestBody = new { prompt, max_tokens = 150 };
        var content = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");

        var response = await _client.PostAsync($"{endpoint}/openai/deployments/{modelId}/chat/completions?api-version=2024-04-01", content);
        return await response.Content.ReadAsStringAsync();
    }
}
