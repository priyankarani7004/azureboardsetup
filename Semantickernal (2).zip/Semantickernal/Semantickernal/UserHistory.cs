﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Semantickernal
{
    public class UserStory
    {
        public string Title { get; set; }
        public int DurationDays { get; set; }
        public string Sprint { get; set; }

        public UserStory(string title, int duration, string sprint)
        {
            Title = title;
            DurationDays = duration;
            Sprint = sprint;
        }
    }

}
