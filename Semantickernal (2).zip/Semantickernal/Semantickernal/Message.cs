﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Semantickernal
{
    public class Message
    {
        public string Author { get; }
        public string Content { get; }

        public Message(string author, string content)
        {
            Author = author;
            Content = content;
        }
    }
}
