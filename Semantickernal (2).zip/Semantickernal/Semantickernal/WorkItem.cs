﻿namespace Semantickernal
{
    public class WorkItem
    {
        string id { get; set; }
    }
}