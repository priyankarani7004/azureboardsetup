﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Semantickernal
{
    public class TimelineTask
    {
        public string Title { get; set; }
        public double DurationHours { get; set; }
    }
}
