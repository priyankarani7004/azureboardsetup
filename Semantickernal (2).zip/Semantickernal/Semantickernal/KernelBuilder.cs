using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using System.Net.Http;

public class KernelBuilderSetup
{
    public static Kernel InitializeKernel(HttpClient client)
    {
        var builder = Kernel.CreateBuilder()
            .AddAzureOpenAIChatCompletion("gpt-4", "https://soumenopenai.openai.azure.com", "your-api-key", httpClient: client);
        
        return builder.Build();
    }
}
