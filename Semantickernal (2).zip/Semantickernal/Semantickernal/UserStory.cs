public class UserStory
{
    public string Title { get; set; }
    public int DurationDays { get; set; }
    public string Sprint { get; set; }
}
